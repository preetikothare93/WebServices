package com.ibm.exceptions;

import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

import com.ibm.beans.ErrorMessage;

//@Provider
public class DataNotFoundExceptionMapper implements ExceptionMapper<DataNotFound>{

	@Override
	public Response toResponse(DataNotFound arg0) {
		// TODO Auto-generated method stub
		ErrorMessage errMsg=new ErrorMessage(arg0.getMessage(), 404, "Vist: http://javabrains.org");
		return Response.status(Status.NOT_FOUND).entity(errMsg).build();
	}

}

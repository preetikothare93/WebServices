package com.ibm.exceptions;

public class DataNotFound extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5495444033147738988L;
	public DataNotFound(String message) {
	// TODO Auto-generated constructor stub
	super(message);
}
}

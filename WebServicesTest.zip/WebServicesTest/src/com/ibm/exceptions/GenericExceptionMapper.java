package com.ibm.exceptions;

import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

import com.ibm.beans.ErrorMessage;

// @Provider uncomment it when want to use this generic exception
public class GenericExceptionMapper  implements ExceptionMapper<Throwable>{

	@Override
	public Response toResponse(Throwable arg0) {
		// TODO Auto-generated method stub
		ErrorMessage errMsg=new ErrorMessage(arg0.getMessage(), 500, "Vist: http://javabrains.org");
		return Response.status(Status.INTERNAL_SERVER_ERROR).entity(errMsg).build();
	}
}

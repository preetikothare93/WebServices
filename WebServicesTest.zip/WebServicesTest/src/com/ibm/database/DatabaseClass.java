package com.ibm.database;

import java.util.HashMap;
import java.util.Map;

import com.ibm.beans.Message;
import com.ibm.beans.Profile;

public class DatabaseClass {

	private static Map<Integer,Message> msgMap=new HashMap<>();
	private static Map<String,Profile> profileMap=new HashMap<>();
	
	public static Map<Integer,Message> getMessages(){
		
		return msgMap;
	}
   public static Map<String, Profile> getProfiles(){
		
		return profileMap;
	}
	
}

/**
 * 
 */
package com.ibm.exception;

import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

/**
 * @author pramesh_patil
 *
 */
public class AppLogicException extends WebApplicationException {
private static final long serialVersionUID = 1L;
	
	public AppLogicException() { 
		       
		super(Response.status(Response.Status.INTERNAL_SERVER_ERROR).build());         
	} 
	
	public AppLogicException(String message) { 
		        
		super(Response.status(Response.Status.NOT_FOUND).entity(message) 
		                 
		.type(MediaType.TEXT_PLAIN).build()); 
	     
		} 
	public AppLogicException(Throwable exception) { 
        
		super(Response.status(Response.Status.NOT_FOUND).entity(exception.getMessage()) 
		                 
		.type(MediaType.TEXT_PLAIN).build()); 
	     
		} 

}

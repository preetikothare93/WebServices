package com.ibm.service;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

import com.ibm.beans.Message;
import com.ibm.database.DatabaseClass;



public class MessageService {
	private static Map<Integer,Message> msgMap=DatabaseClass.getMessages();
	
	public MessageService() {
		// TODO Auto-generated constructor stub
		
		msgMap.put(1,new Message(1,"hi","Preeti"));
		msgMap.put(2,new Message(2,"hello","Neeti"));
		msgMap.put(3,new Message(3,"hie","kreeti"));
		msgMap.put(4,new Message(4,"Gm","shruti"));
		msgMap.put(5,new Message(5,"GN","kirti"));
		//msgMap.put(1,new Message(1,"hi","Preeti"));
	}
	public List<Message> getAlllMessages() {
		/*Message m1=new Message(1, "Hi Preeti", "Preeti");
		Message m2=new Message(2, "Hi Neeti", "Neeti");
		List<Message> list=new ArrayList<Message>();
		list.add(m1);
		list.add(m2);
		return list;*/
		return new ArrayList<Message>(msgMap.values());
	}
	
	public List<Message> getAllMessagesForYear(int year){
		List<Message> messagesForYear=new ArrayList<>();
		Calendar cal=Calendar.getInstance();
		for(Message messgae:msgMap.values()){
			cal.setTime(messgae.getCreated());
			if(cal.get(Calendar.YEAR)==year){
				messagesForYear.add(messgae);
			}
				
			
		}
		
		return messagesForYear;
	}
	
	public List<Message> getAllMessagesPaginated(int start,int size){
		
		ArrayList<Message> list=new ArrayList<Message>(msgMap.values());
		if(start+size >list.size())
			return new ArrayList<Message>();
		return list.subList(start, start+size);
	}
	
	public Message getMessage(int id){
		return msgMap.get(id);
	}

	public Message addMessage(Message msg){
		msg.setId(msgMap.size()+1);
		msgMap.put(msg.getId(), msg);
		return msg;
	}

	public Message updateMessage(Message msg){
		if(msg.getId() <= 0){
			return null;
		}
		msgMap.put(msg.getId(), msg);
		return msg;
	}
	public Message removeMessage(int id){
		return msgMap.remove(id);
	}

}


package com.ibm.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.ibm.beans.Message;
import com.ibm.beans.Profile;
import com.ibm.database.DatabaseClass;

public class ProfileService {
	private static Map<String, Profile> profiles=DatabaseClass.getProfiles();
	
	
	public ProfileService() {
		// TODO Auto-generated constructor stub
	profiles.put("Preeti", new Profile(1, "Preeti", "Preeti", "Kothare"));
	
	}
	public List<Profile> getAllProfiles() {
		
		return new ArrayList<Profile>(profiles.values());
	}
	public Profile getProfile(String profileName){
		return profiles.get(profileName);
	}

	public Profile addProfile(Profile prf){
		prf.setId(profiles.size()+1);
		profiles.put(prf.getProfileName(), prf);
		return prf;
	}

	public Profile updateProfile(Profile prf){
		if(prf.getProfileName().isEmpty()){
			return null;
		}
		profiles.put(prf.getProfileName(), prf);
		return prf;
	}
	public Profile removeProfile(String profileName){
		return profiles.remove(profileName);
	}
	
}

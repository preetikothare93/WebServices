package com.ibm.resources;

import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;


@Path("/")
public class CommentResource {


@POST
	@Path("/first")
	public String getSubResrc()
	{

		return "subresource found...!=";
	}
	
	@GET
	@Path("/two") 
	public int getCommentId()
	{

		return 123;
	}
	
}

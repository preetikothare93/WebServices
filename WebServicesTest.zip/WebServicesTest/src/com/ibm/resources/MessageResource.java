/**
 * 
 */
package com.ibm.resources;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;


import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.UriInfo;
import javax.xml.ws.BindingType;

import com.ibm.beans.ErrorMessage;
import com.ibm.beans.Message;
import com.ibm.exceptions.DataNotFound;
import com.ibm.resources.beans.MessageFilterBean;
import com.ibm.service.MessageService;
import com.sun.jersey.api.NotFoundException;

/**
 * @author pramesh_patil
 * 
 */
@Path("Messages")
//@Consumes(MediaType.APPLICATION_JSON)
@Consumes(value={MediaType.APPLICATION_JSON,MediaType.TEXT_XML})
//@Produces(MediaType.APPLICATION_JSON)
@Produces(value={MediaType.APPLICATION_JSON,MediaType.TEXT_XML})
public class MessageResource {

 MessageService mesageSer =new MessageService();
	
	@GET
	@Path("/allMsg")
	/*@Produces(MediaType.APPLICATION_JSON)*/
	@Produces(MediaType.APPLICATION_JSON)
	public List<Message> getMessages(@QueryParam("year") int year,@QueryParam("start") int start,@QueryParam("size") int size) {
	
	/*public List<Message> getMessages(@BeanParam MessageFilterBean filterbean) {
	access these bean param using filterbean.year,filterbean.size etc. 
	
		*/
	
		
	  /* if(year > 0)
	   {  return mesageSer.getAllMessagesForYear(year); 
	   }
	   if(start >= 0 && size >= 0){
		   return mesageSer.getAllMessagesPaginated(start, size);
	   }*/
		System.out.println("JSON exceuted");
		return mesageSer.getAlllMessages();
		
		
	}
	
	
	@GET
	@Path("/allMsg")
	@Produces(MediaType.TEXT_XML)
	/*@Produces(MediaType.APPLICATION_JSON)*/
	public List<Message> getXmlMessages(@QueryParam("year") int year,@QueryParam("start") int start,@QueryParam("size") int size) {
	
	/*public List<Message> getMessages(@BeanParam MessageFilterBean filterbean) {
	access these bean param using filterbean.year,filterbean.size etc. 
	
		*/
	
		
	  /* if(year > 0)
	   {  return mesageSer.getAllMessagesForYear(year); 
	   }
	   if(start >= 0 && size >= 0){
		   return mesageSer.getAllMessagesPaginated(start, size);
	   }*/
		System.out.println("xml exceuted");
		return mesageSer.getAlllMessages();
		
		
	}
	
	/*
	 *------USE THIS FOR Exception handling---------
	  
	  @GET
	@Path("{id}")
	@Produces(MediaType.APPLICATION_JSON)
	public Message getMessage(@PathParam("id") int idVal){
		
		Message msg=mesageSer.getMessage(idVal);
		
		if(msg==null){
			String v=String.valueOf(idVal);
		//	throw new DataNotFound("Message with id "+ v +" Not found"); // for custom exception
			ErrorMessage errMsg=new ErrorMessage("NOT FOUND YOUR DATA", 404, "Vist: http://javabrains.org");
			Response rsp= Response.status(Status.NOT_FOUND).entity(errMsg).build();
			//throw new WebApplicationException(rsp);
			throw new NotFoundException();
		}
		return mesageSer.getMessage(idVal);
	}*/
	
	
	//----- USE THIS for giveing URL to msgs
	@GET
	@Path("{id}")
	/*@Produces(MediaType.APPLICATION_JSON)*/
	public Message getMessage(@PathParam("id") int idVal,@Context UriInfo uriinfo){
		
		Message msg=mesageSer.getMessage(idVal);
		String id=String.valueOf(msg.getId());
		String uri=uriinfo.getBaseUriBuilder().
				path(MessageResource.class).
				path(id).build().
				toString();
		msg.addLink(uri, "Self");
		msg.addLink(getUriForProfile(uriinfo,msg), "Profile");
		return msg;
	}
	private String getUriForProfile(UriInfo uriinfo, Message msg) {
		// TODO Auto-generated method stub
		String id=String.valueOf(msg.getId());
		String uri=uriinfo.getBaseUriBuilder().
				path(ProfileResource.class).
				path(id).build().
				toString();
		System.out.println("URI= "+uri);
		return uri;
	}

	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	public Message addMessage(Message msg){
		System.out.println("JSON added");
		return mesageSer.addMessage(msg);
	}
	
	@POST
	@Consumes(MediaType.TEXT_XML)
	public Message addXmlMessage(Message msg){
		System.out.println("Xml added");
		return mesageSer.addMessage(msg);
	}
	
//add new msg with cusom response
	
	@POST
	@Path("/resp")
	public Response addNewMessage(@Context UriInfo uriInfo,Message msg) throws URISyntaxException{
		//return Response.status(Status.CREATED).entity(m1).build(); //for setting only status code
		//to set both status code and location in single lin us this
		System.out.println(uriInfo.getAbsolutePath());
		
		Message m1=mesageSer.addMessage(msg);
		String newId=String.valueOf(m1.getId());
		URI uri=uriInfo.getAbsolutePathBuilder().path(newId).build();
	
		return Response.created(uri).entity(m1).build();
	}
	
	
	@PUT
	@Path("{id}")
/*	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)*/
	public Message updateMessage(@PathParam("id") int id,Message msg){
		msg.setId(id);
		return mesageSer.updateMessage(msg);
	}
	
	@DELETE
	@Path("{id}")
	public void deleteMessage(@PathParam("id") int id){
		
		mesageSer.removeMessage(id);
	}
	
	@GET
	@Path("{id}/comments")
	public CommentResource getCommentResource(){
		
		//return "Comments fgf";
		return new CommentResource();
	}
	/*
	 ----Pramesh code--------
	 
	  
	@Path("/messageList")
	@GET
	@Produces(MediaType.APPLICATION_XML)
	public List<Message> getArticleList() {
	
		Message msg = new Message();
		msg.setId(1);
		
		Message msg2 = new Message();
		msg2.setId(2);
		
		Message msg3 = new Message();
		msg3.setId(3);
		
		List<Message> msgList = new ArrayList<Message>();
		msgList.add(msg);
		msgList.add(msg2);
		msgList.add(msg3);
	
		return msgList;
	}
	
	
	 
	@Path("/test")
	@GET
	public String getMessage() {
		System.out.println("inside test service");

		return "Testing REST service";
	}
*/
	

}

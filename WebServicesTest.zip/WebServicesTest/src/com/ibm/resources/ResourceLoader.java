/**
 * 
 */
package com.ibm.resources;

import java.util.HashSet;
import java.util.Set;

import javax.ws.rs.core.Application;

import org.apache.log4j.Logger;
import org.codehaus.jackson.jaxrs.JacksonJaxbJsonProvider;
import org.codehaus.jackson.map.AnnotationIntrospector;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.xc.JaxbAnnotationIntrospector;

import com.ibm.exception.AppLogicException;
import com.ibm.resources.beans.MessageFilterBean;




/**
 * ResourceLoader class is used to support for JAVA object to JAXB conversion
 * and Serialization and Deserialization of JAXB
 * 
 * @author 
 * 
 */
public class ResourceLoader extends Application {
//	private static final Logger LOGGER = Logger.getLogger(ResourceLoader.class);

	/*@Override
	public Set<Object> getSingletons() {
		LOGGER.info("Executing getSingletons - ResourceLoader");
		Set<Object> objectSet = new HashSet<Object>();
		ObjectMapper mapper = new ObjectMapper();

		try {
		
		AnnotationIntrospector primary = new JaxbAnnotationIntrospector();
		AnnotationIntrospector secondary = new JaxbAnnotationIntrospector();
		AnnotationIntrospector pair = AnnotationIntrospector.pair(primary,
				secondary);
		mapper.getDeserializationConfig().withAnnotationIntrospector(pair);
		mapper.getSerializationConfig().withAnnotationIntrospector(pair);

		JacksonJaxbJsonProvider jaxbProvider = new JacksonJaxbJsonProvider();
		jaxbProvider.setMapper(mapper);
		objectSet.add(jaxbProvider);
		}catch(Exception e) {
			LOGGER.error(e.getMessage(),e);
			throw new AppLogicException();
		}
		LOGGER.info("getSingletons - ResourceLoader completed");
		return objectSet;

	}*/

	@Override
	public Set<Class<?>> getClasses() {
		//LOGGER.info("Executing getClasses - ResourceLoader ");
		Set<Class<?>> resourceList = new HashSet<Class<?>>();
		try {
		resourceList.add(MessageResource.class);
		resourceList.add(ProfileResource.class);
		resourceList.add(InjectDemoResource.class);
		resourceList.add(MessageFilterBean.class);
		//resourceList.add(CommentResource.class);
		
		}catch(Exception e) {
			//LOGGER.error(e.getMessage(),e );
			throw new AppLogicException();
		}
	//	LOGGER.info("getClasses - ResourceLoader completed ");
		return resourceList;
	}

}

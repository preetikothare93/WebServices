package com.ibm.beans;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class ErrorMessage {

	private String errorMessage;
	private int errorCode;
	private String documenttation;
	public ErrorMessage() {
		// TODO Auto-generated constructor stub
	}
	
	public ErrorMessage(String errorMessage, int errorCode,
			String documenttation) {
		super();
		this.errorMessage = errorMessage;
		this.errorCode = errorCode;
		this.documenttation = documenttation;
	}

	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	public int getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}
	public String getDocumenttation() {
		return documenttation;
	}
	public void setDocumenttation(String documenttation) {
		this.documenttation = documenttation;
	}
	
	
}

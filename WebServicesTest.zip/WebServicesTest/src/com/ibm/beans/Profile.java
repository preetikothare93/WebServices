package com.ibm.beans;

import java.util.Date;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Profile {
	
	public int id;
	public String profileName;
	public String firstName;
	public String lastName;
	public Date created;
	
	public Profile() {
		// TODO Auto-generated constructor stub
	}

	public Profile(int id, String profileName, String firstName,
			String lastName) {
		super();
		this.id = id;
		this.profileName = profileName;
		this.firstName = firstName;
		this.lastName = lastName;
	}

	public long getId() {
		return id;
	}
    @XmlElement
	public void setId(int id) {
		this.id = id;
	}

	public String getProfileName() {
		return profileName;
	}

	@XmlElement
	public void setProfileName(String profileName) {
		this.profileName = profileName;
	}

	public String getFirstName() {
		return firstName;
	}

	@XmlElement
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	@XmlElement
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Date getCreated() {
		return created;
	}
	@XmlElement
	public void setCreated(Date created) {
		this.created = created;
	}

	
}
